//
//  ViewController.swift
//  TestProject
//
//  Created by SAI on 10/04/20.
//  Copyright © 2020 Sai Kishore. All rights reserved.
//

import UIKit

class ViewController: TestProjectBaseVC {

    override func viewDidLoad() {
        super.viewDidLoad()
        

        // Do any additional setup after loading the view.
    }
    
    override func viewWillAppear(_ animated: Bool) {
        // makes navigation bar clear
        self.navigationController?.navigationBar.makeClear()
        // make uibarbutton with menu or back
        self.navigationItem.leftBarButtonItem = UIBarButtonItem.menuOrBackButton(self, action: #selector(writeYourAction), imageName: "Write Your Image Name")
    }
    
    override func viewWillDisappear(_ animated: Bool) {
        super.viewWillDisappear(animated)
        self.navigationTitleImageView.removeFromSuperview()
    }
    
    
    @IBAction func btnTapped(_ sender: UIButton) {
        let nextVc = self.storyboard?.instantiateViewController(withIdentifier: "HomeViewController") as! HomeViewController
        self.navigationController?.pushViewController(nextVc, animated: false)
    }
    

}

