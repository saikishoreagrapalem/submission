//
//  TestProjectBaseVC.swift
//  TestProject
//
//  Created by SAI on 10/04/20.
//  Copyright © 2020 Sai Kishore. All rights reserved.
//

import UIKit
import DGActivityIndicatorView


class TestProjectBaseVC: UIViewController {

    var activityIndicatorView: DGActivityIndicatorView?
    lazy var navigationTitleImageView = UIImageView()

    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.setupActivityView()

        // Do any additional setup after loading the view.
    }
    
    @objc func writeYourAction() {
        
    }
    
    @objc func backAction() {
        self.navigationController?.popViewController(animated: false)
    }
    
    func showAlert(withTitle title: String, message: String, OkButtonTitle: String, cancelButtonTitle: String, okHandler:@escaping ()-> Void?, cancelHandler:@escaping ()->Void?){
        
        let alertController = UIAlertController(title: title, message: message, preferredStyle: UIAlertController.Style.alert)
        alertController.addAction(UIAlertAction(title: OkButtonTitle, style: UIAlertAction.Style.default, handler: { (action) in
            okHandler()
        }))
        alertController.addAction(UIAlertAction(title: cancelButtonTitle, style: UIAlertAction.Style.cancel, handler: { (action) in
            cancelHandler()
        }))
        
        self.present(alertController, animated: true, completion: nil)
    }
    
    func showAlert(withTitle title: String = "Error", message : String = "Something went wrong!", okHandler: @escaping ()-> Void?) {
        
        let alertController = UIAlertController(title: title, message: message, preferredStyle: UIAlertController.Style.alert)
        alertController.addAction(UIAlertAction(title: "OK", style: UIAlertAction.Style.default, handler: { (action) in
            okHandler()
        }))
        self.present(alertController, animated: true, completion: nil)
    }
    
    func setupActivityView(){
        activityIndicatorView = DGActivityIndicatorView(type: DGActivityIndicatorAnimationType.ballScaleRipple, tintColor: UIColor.theme)
        activityIndicatorView?.frame = CGRect(x: UIScreen.main.bounds.size.width/2 - 20, y: UIScreen.main.bounds.size.height/2 - 20.0, width: 40.0, height: 40.0)
        self.view.addSubview(activityIndicatorView!)
        activityIndicatorView?.isHidden = true
    }
    
    func startAnimatingActivityIndicator(){
        self.view.isUserInteractionEnabled = false
        self.view.alpha = 0.8
        activityIndicatorView?.isHidden = false
        activityIndicatorView?.startAnimating()
    }
    
    func stopAnimatingActivityIndicator(){
        self.view.isUserInteractionEnabled = true
        self.view.alpha = 1.0
        activityIndicatorView?.stopAnimating()
        activityIndicatorView?.isHidden = true
    }

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
