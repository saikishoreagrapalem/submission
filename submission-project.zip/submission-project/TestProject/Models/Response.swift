//
//  Response.swift
//  TestProject
//
//  Created by SAI on 10/04/20.
//  Copyright © 2020 Sai Kishore. All rights reserved.
//

import Foundation


class Response : Codable {
    
    let status: String?
    let response: DataResponse?
    
    enum CodingKeys: String, CodingKey {
           case status = "status"
           case response = "response"
       }
    
}

class DataResponse : Codable {
    
    let docs: [Docs]?
    
    enum CodingKeys: String, CodingKey {
             case docs = "docs"
         }
    
}

class Docs : Codable {
    
    let abstract: String?
    let web_url: String?
    let snippet: String?
    let lead_paragraph: String?
    let source: String?
    let headline: HeadLine?
    let multimedia: [MultiMedia]?
    let pub_date: String?
    let document_type: String?
    let section_name: String?
    let title: String?
    
    enum CodingKeys: String, CodingKey {
        case abstract = "abstract"
        case web_url = "web_url"
        case snippet = "snippet"
        case lead_paragraph = "lead_paragraph"
        case source = "source"
        case headline = "headline"
        case multimedia = "multimedia"
        case pub_date = "pub_date"
        case document_type = "document_type"
        case section_name = "section_name"
        case title = "title"
    }
    
}


class HeadLine : Codable {
    
    let main: String?
    let print_headline: String?
    
    enum CodingKeys: String, CodingKey {
           case main = "main"
           case print_headline = "print_headline"
           
       }
    
}

struct MultiMedia :  Codable {
    let url: String?
    
    enum CodingKeys: String, CodingKey {
        case url = "url"
        
    }
}
